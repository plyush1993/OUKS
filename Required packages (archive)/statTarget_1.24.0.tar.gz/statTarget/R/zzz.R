.onAttach <- function(...) {
    packageStartupMessage("\nUse 'statTargetGUI()' to start the GUI program. For details see https://stattarget.github.io.\n")
    # statTarget::statTargetGUI()
}
